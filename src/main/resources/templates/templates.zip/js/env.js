const localData = window.localStorage;
const serverUrl = 'http://localhost';
const localStorageTokenKey = 'msl-storage-token';